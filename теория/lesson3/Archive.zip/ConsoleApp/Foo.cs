namespace ConsoleApp
{
    public static class Foo
    {
        public static void Bar()
        {

        }
    }
}
