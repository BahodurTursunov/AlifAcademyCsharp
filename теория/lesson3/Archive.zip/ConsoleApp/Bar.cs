namespace ConsoleApp
{
    public static class Bar
    {
        public static void Foo()
        {

        }
    }
}
