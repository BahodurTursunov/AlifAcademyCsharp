﻿using System;
using ConsoleApp;

// [type] [name] = [value];
float f1 = 1.123f;
decimal d1 = 1.2434554m;
double d2 = 34.3453545345d;

char ch = '!';

string str1;
string str0 = null;

string str2 = string.Empty;
string str3 = "";

string str = "Text";
char[] chars = new[] { 'T', 'e', 'x', 't' };
string strFromChars = new(chars);

string text = "\t\t\t\n";
string text2 = "Hello,\nWorld!";
string text3 = @"C:\Users\foo\bar\help.cs";

str3 = str + strFromChars;
// TextText

A();
B();

D d = new();

Foo.Bar();
Bar.Foo();
Console.WriteLine("Hello!");


void A() { }
void B() { }

class D { }
class N { }
