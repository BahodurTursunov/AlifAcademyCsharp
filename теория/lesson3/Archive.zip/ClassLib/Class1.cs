﻿namespace ClassLib;

public class Class1
{

}
